package Week_3;

import java.util.Set;
import java.util.TreeMap;

public class ChatMssgsTM {
	public static void main(String[] args) {
		TreeMap<String, String> hmss = new TreeMap<>((s1, s2) -> s1.compareTo(s2));

		hmss.put("name1", "msg01");
		hmss.put("name2", "msg02");
		hmss.put("name3", "msg03");
		hmss.put("name4", "msg04");
		hmss.put("name5", "msg05");

		Set<String> ss = hmss.keySet();

		for (String item_key : ss) {
			System.out.println(item_key + " ----> " + hmss.get(item_key));
		}

	}

}

