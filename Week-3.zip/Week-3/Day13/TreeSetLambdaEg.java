package Week_3;

import java.util.Collections;
import java.util.Iterator;
import java.util.TreeSet;


class Country{
	private String name;
	private double gdp;
	
	public Country(String name, double gdp) {
		super();
		this.name = name;
		this.gdp = gdp;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getGdp() {
		return gdp;
	}
	public void setGdp(double gdp) {
		this.gdp = gdp;
	}
	@Override
	public String toString() {
		return "Country [name=" + name + ", gdp=" + gdp + "]";
	}
	
	
	
}


public class TreeSetLambdaEg {
	public static void main(String[] args) {
			
		TreeSet<Country> tss = new TreeSet<Country>(
				(c1,c2)->(int)(c2.getGdp()-c1.getGdp())
				);
		
		tss.add(new Country("Country1", 10.75));
		tss.add(new Country("Country2", 2.33));
		tss.add(new Country("Country3", 13.34));
		
Iterator<Country> itrc = tss.iterator();
		
		/*while(itrc.hasNext()) {
			System.out.println(itrc.next());
		}
		*/
	
		
		Country cmin = Collections.min(tss, (c1,c2)->c1.getName().compareTo(c2.getName()));
		System.out.println("Minimum country element is "+cmin);
		
		Country cmax = Collections.max(tss, (c1,c2)->c1.getName().compareTo(c2.getName()));
		System.out.println("Maximum country element is "+cmax);
	
	}	
}
