package com.egjson;

import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WriteJSONEg {
public static void main(String[] args) throws Exception {
	
	Address addr = new Address("street1", "city1", 123456);
	Person obj = new Person("Janvi", 53, addr);
	obj.setAge(46);
	obj.setName("Ravi");
	
	ObjectMapper mapper = new ObjectMapper();
	
	FileOutputStream fos = new FileOutputStream("person.json");
	
	mapper.writeValue(fos,  obj);
}
}
