package com.egjson;

import java.io.*;

import com.fasterxml.jackson.databind.ObjectMapper;

public class WriteJSONEg {
public static void main(String[] args) throws Exception {
	
	//Address[] addrs = new Address[2];
	Address[] addrs = {new Address("street1", "city1", 123456), new Address("street2", "city2", 789012)};
	
	Person obj = new Person("Janvi", 53, addrs);
	obj.setAge(46);
	obj.setName("Ravi");
	
	ObjectMapper mapper = new ObjectMapper();
	
	FileOutputStream fos = new FileOutputStream("person.json");
	
	mapper.writeValue(fos,  obj);
	String pjson = mapper.writeValueAsString(obj);
	
	System.out.println("JSON File has been completed, Pls check\n" + pjson);
}
}
