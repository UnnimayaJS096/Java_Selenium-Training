package com.dbeg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Day20_Assignmnt1 {
	public static void main(String arg[])
	{
		Connection connection = null;
		try {
			// below two lines are used for connectivity.
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(
				"jdbc:mysql://127.0.0.1:3306/sept2",
				"root", "pass@word1");

			// mydb is database
			// mydbuser is name of database
			// mydbuser is password of database
			
			//Prepare the statement
			PreparedStatement ps = connection.prepareStatement("UPDATE messages SET ptype=? WHERE ptype=?");
			
			//set required fields in above prepared statement
			ps.setString(1,  "I");
			ps.setString(2,  "Internal");
			
			//execute prepare statement
			int rec = ps.executeUpdate();
			System.out.println("Updated " + rec + " records with I");
			
			ps.setString(1,  "E");
			ps.setString(2,  "External");
			
			rec = ps.executeUpdate();
			System.out.println("Updated " + rec + " records with E");
			
		
			ps.close();
			connection.close();
		}
		catch (Exception exception) {
			System.out.println(exception);
		}
	} // function ends
} // class ends
