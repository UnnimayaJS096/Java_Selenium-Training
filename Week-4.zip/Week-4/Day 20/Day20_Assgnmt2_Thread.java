package com.dbeg;

//to print characters individually from a string using multi threading concept
class DisplayChars extends Thread {

	String givenString = "Am working with multithreading program";

	@Override
	public void run() {
		try {

			for (int i = 0; i < givenString.length(); i++) {
				System.out.print(givenString.charAt(i)+" ");

				Thread.sleep(30);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}

public class Day20_Assgnmt2_Thread {

	static String string1 = "Am working with multithreading program";

	public static void main(String[] args) {

		try {

			PrintChars thread = new PrintChars();
			thread.start();
			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");
				Thread.sleep(25);
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
