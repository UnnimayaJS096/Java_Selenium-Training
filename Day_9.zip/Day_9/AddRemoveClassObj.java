package com.p9;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class CityData {
   private String name;
   private long pincode;
   private String capitalCity;

   // Constructor
   public CityData(String name, long pincode, String capitalCity) {
       this.name = name;
       this.pincode = pincode;
       this.capitalCity = capitalCity;
   }

   // Getter and Setter methods
   public String getName() {
       return name;
   }

   public void setName(String name) {
       this.name = name;
   }

   public long getPincode() {
       return pincode;
   }

   public void setPincode(long pincode) {
       this.pincode = pincode;
   }

   public String getCapitalCity() {
       return capitalCity;
   }

   public void setCapitalCity(String capitalCity) {
       this.capitalCity = capitalCity;
   }

   // toString method
   @Override
   public String toString() {
       return "City [name=" + name + ", pincode=" + pincode + ", capital_city=" + capitalCity + "]";
   }
}

public class AddRemoveClassObj {
   private static List<CityData> cities = new ArrayList<>();

   public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

       while (true) {
           System.out.println("Menu:");
           System.out.println("1. Add a City");
           System.out.println("2. Remove a City");
           System.out.println("3. Display Cities");
           System.out.println("4. Exit");
           System.out.print("Choose an option: ");
           int choice = scanner.nextInt();
           scanner.nextLine(); // Consume the newline

           switch (choice) {
               case 1:
                   addCity(scanner);
                   break;
               case 2:
                   removeCity(scanner);
                   break;
               case 3:
                   displayCities();
                   break;
               case 4:
                   System.out.println("Exiting...");
                   scanner.close();
                   return; // Exit the program
               default:
                   System.out.println("Invalid option. Please try again.");
           }
       }
   }

   private static void addCity(Scanner scanner) {
       System.out.println("Enter details for the city:");
       
       System.out.print("Name: ");
       String name = scanner.nextLine();
       
       System.out.print("Pincode: ");
       long pincode = scanner.nextLong();
       scanner.nextLine(); // Consume the newline
       
       System.out.print("Capital City: ");
       String capitalCity = scanner.nextLine();
       
       // Create a new City object and add it to the list
       cities.add(new CityData(name, pincode, capitalCity));
       System.out.println("City added successfully.");
   }

   private static void removeCity(Scanner scanner) {
       System.out.print("Enter the name of the city to remove: ");
       String name = scanner.nextLine();
       
       Iterator<CityData> iterator = cities.iterator();
       boolean found = false;
       
       while (iterator.hasNext()) {
    	   CityData city = iterator.next();
           if (city.getName().equalsIgnoreCase(name)) {
               iterator.remove();
               found = true;
               System.out.println("City removed successfully.");
               break;
           }
       }
       
       if (!found) {
           System.out.println("City not found.");
       }
   }
 private static void displayCities() {
       if (cities.isEmpty()) {
           System.out.println("No cities to display.");
       } else {
           System.out.println("List of Cities:");
           for (CityData city : cities) {
               System.out.println(city);
           }
       }
   }
}

